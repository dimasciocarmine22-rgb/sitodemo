NOVA STUDIO — DEMO SITO WEB + CHATBOT

CONTENUTO
- index.html: sito responsive completo con chatbot FAQ locale.

COME APRIRLO
1. Estrai il file ZIP (se hai scaricato il pacchetto).
2. Apri index.html con Chrome, Edge o Firefox.
3. Premi “Chiedi al chatbot” per provare la chat.

COME PERSONALIZZARLO
1. Apri index.html con un editor di testo (per esempio Visual Studio Code, gratuito).
2. Cerca “Nova Studio” e sostituiscilo con il nome della tua agenzia.
3. Cerca “inserisci-la-tua-email@example.com” e inserisci la tua email reale in entrambe le occorrenze rilevanti.
4. Aggiorna servizi, prezzi, testi e contatti: i prezzi presenti sono esempi dimostrativi.
5. Salva e riapri/ricarica index.html nel browser.

PUBBLICAZIONE GRATUITA (ESEMPIO: GITHUB PAGES)
1. Crea un account su https://github.com/.
2. Crea un nuovo repository pubblico, ad esempio “nova-studio-demo”.
3. Carica index.html nella cartella principale del repository.
4. Apri Settings > Pages.
5. In “Build and deployment”, seleziona “Deploy from a branch”, poi il branch “main” e la cartella “/ (root)”, quindi salva.
6. Attendi il completamento della pubblicazione: GitHub mostrerà l'indirizzo pubblico nelle impostazioni Pages.
Nota: interfacce e condizioni dei servizi possono cambiare; non serve acquistare un dominio personalizzato, ma un dominio proprio è normalmente a pagamento.

LIMITI IMPORTANTI
- Il chatbot è una demo con risposte preimpostate: non usa un modello IA e non manda messaggi a un server.
- Il modulo contatti apre il programma email tramite mailto: non conserva né invia dati a un database. Prima dell'uso, sostituisci l'email segnaposto.
- Prezzi, testimonianze e offerte non sono risultati garantiti; i prezzi sono esempi da adattare.
- Prima di vendere siti a clienti reali, concorda per iscritto perimetro del lavoro, revisioni, manutenzione, dominio, hosting, privacy e costi ricorrenti. Non pubblicare dati personali senza autorizzazione.
